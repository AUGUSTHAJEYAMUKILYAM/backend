package com.examly.springapp.controller;

import com.examly.springapp.model.Instructor;
import com.examly.springapp.service.InstructorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/instructors")
public class InstructorController {

    @Autowired
    private InstructorService instructorService;

    @PostMapping
public ResponseEntity<Instructor> createInstructor(@RequestBody(required = false) Instructor instructor) {
    if (instructor == null) {
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }
    Instructor saved = instructorService.saveInstructor(instructor);
    return new ResponseEntity<>(saved, HttpStatus.CREATED);
}

    @GetMapping
    public ResponseEntity<List<Instructor>> getAllInstructors() {
        List<Instructor> instructors = instructorService.getAllInstructors();
        if (instructors.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(instructors, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Instructor> getInstructorById(@PathVariable Long id) {
        Instructor instructor = instructorService.getInstructorById(id);
        return new ResponseEntity<>(instructor, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Instructor> updateInstructor(@PathVariable Long id, @RequestBody Instructor instructor) {
        Instructor updated = instructorService.updateInstructor(id, instructor);
        return new ResponseEntity<>(updated, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInstructor(@PathVariable Long id) {
        instructorService.deleteInstructor(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/page/{page}/{size}")
    public ResponseEntity<Page<Instructor>> getInstructorsWithPagination(@PathVariable int page, @PathVariable int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Instructor> instructors = instructorService.getInstructorsWithPagination(pageable);
        return new ResponseEntity<>(instructors, HttpStatus.OK);
    }

    @GetMapping("/specialization/{specialization}")
    public ResponseEntity<?> getInstructorsBySpecialization(@PathVariable String specialization) {
        List<Instructor> instructors = instructorService.getInstructorsBySpecialization(specialization);
        if (instructors.isEmpty()) {
            return new ResponseEntity<>("No instructors found with specialization: " + specialization, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(instructors, HttpStatus.OK);
    }
}