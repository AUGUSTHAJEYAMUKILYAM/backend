# cbd82317-6849-43a0-be32-60009b3674f2-e58092aa-99c3-4a90-ad97-a8ab3ffa7a59
Repository for Teams Project code and project management
